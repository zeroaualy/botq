"""
Martingale Manager — Bot Q3 Beta
Real implementation. Persistent. Shared by ALL execution paths.
Single source of truth for trade sizing when martingale is active.
"""
import logging
from typing import Optional
from db.database import (
    load_martingale_state,
    save_martingale_state,
)

logger = logging.getLogger(__name__)


class MartingaleManager:
    """
    Manages martingale sequencing with full state persistence.

    Rules:
    - After LOSS  → increase level, multiply value
    - After WIN   → reset to level 0 (base value)
    - After EMPATE→ keep same level (no double, no reset)
    - If level >= max_levels → block, notify, wait manual reset
    - State survives bot restart (SQLite)
    """

    def __init__(self, global_config: dict):
        """
        Args:
            global_config: Live reference to CONFIG dict.
                           Reads "valor_entrada", "martingale",
                           "martingale_multiplier", "martingale_max_levels".
        """
        self._cfg = global_config
        # In-memory state (loaded from DB on startup)
        self._level: int = 0
        self._consecutive_losses: int = 0
        self._loaded: bool = False

    # ─────────────────────────────────────────────────────────
    # CONFIG HELPERS
    # ─────────────────────────────────────────────────────────

    @property
    def enabled(self) -> bool:
        return bool(self._cfg.get("martingale", False))

    @property
    def base_value(self) -> float:
        return float(self._cfg.get("valor_entrada", 10.0))

    @property
    def multiplier(self) -> float:
        return float(self._cfg.get("martingale_multiplier", 2.0))

    @property
    def max_levels(self) -> int:
        return int(self._cfg.get("martingale_max_levels", 3))

    # ─────────────────────────────────────────────────────────
    # LIFECYCLE
    # ─────────────────────────────────────────────────────────

    async def load(self):
        """Load state from DB. Call once on startup."""
        state = await load_martingale_state()
        self._level = state.get("current_level", 0)
        self._consecutive_losses = state.get("consecutive_losses", 0)
        self._loaded = True
        logger.info(
            f"✅ MartingaleManager loaded — level={self._level}, "
            f"losses={self._consecutive_losses}, enabled={self.enabled}"
        )

    # ─────────────────────────────────────────────────────────
    # CORE API
    # ─────────────────────────────────────────────────────────

    def get_next_value(self) -> tuple[float, int]:
        """
        Returns (trade_amount, current_level).
        Call BEFORE every execution to get the correct amount.

        If martingale is disabled → returns (base_value, 0).
        If max_levels exceeded → returns (0.0, level) to BLOCK trade.
        """
        if not self.enabled:
            return self.base_value, 0

        if self._level >= self.max_levels:
            logger.warning(
                f"⛔ Martingale at max level ({self._level}/{self.max_levels}). "
                "Block until manual reset."
            )
            return 0.0, self._level

        amount = self.base_value * (self.multiplier ** self._level)
        return round(amount, 2), self._level

    async def register_result(self, result: str):
        """
        Update state after a trade settles.
        result: "WIN" | "LOSS" | "EMPATE"
        """
        if not self.enabled:
            return

        if result == "WIN":
            self._level = 0
            self._consecutive_losses = 0
        elif result == "LOSS":
            self._level = min(self._level + 1, self.max_levels)
            self._consecutive_losses += 1
        # EMPATE: keep same level

        await save_martingale_state(
            level=self._level,
            consecutive_losses=self._consecutive_losses,
            base_value=self.base_value,
            last_result=result,
        )
        logger.info(
            f"📊 Martingale updated — result={result}, "
            f"level={self._level}/{self.max_levels}, "
            f"next_value=${self.base_value * (self.multiplier ** self._level):.2f}"
        )

    async def manual_reset(self):
        """Reset sequence manually (e.g. after hitting max_levels)."""
        self._level = 0
        self._consecutive_losses = 0
        await save_martingale_state(
            level=0,
            consecutive_losses=0,
            base_value=self.base_value,
            last_result=None,
        )
        logger.info("🔄 Martingale reset manually")

    # ─────────────────────────────────────────────────────────
    # STATUS
    # ─────────────────────────────────────────────────────────

    def get_status(self) -> dict:
        """Return current state for display."""
        amount, level = self.get_next_value()
        blocked = (self.enabled and level >= self.max_levels)
        return {
            "enabled": self.enabled,
            "level": self._level,
            "max_levels": self.max_levels,
            "consecutive_losses": self._consecutive_losses,
            "multiplier": self.multiplier,
            "base_value": self.base_value,
            "next_value": amount,
            "blocked": blocked,
        }
