"""
Gerador Automático de Sinais
Usa MyIQ (dados reais) + Gemini AI
Não interfere com sinais manuais
"""
import asyncio
import logging
import json
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from typing import Optional, Dict

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")


class AutoSignalGenerator:
    """Gerador automático de sinais com MyIQ + Gemini"""

    def __init__(self, iq_client, gemini_client, runtime, config=None):
        self.iq_client = iq_client
        self.gemini_client = gemini_client
        self.runtime = runtime
        self.config = config or {}
        self.active = False
        self.task = None
        self.interval = self.config.get("automacao_intervalo_analise", 90)
        self.min_confidence = self.config.get("automacao_confianca_minima", 70)
        self.max_per_hour = self.config.get("max_auto_trades_per_hour", 5)
        self.cooldown_seconds = self.config.get("auto_cooldown_seconds", 120)
        self.generated = []
        self.last_signal_time: Optional[datetime] = None
        self.assets = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "EURJPY", "GBPJPY"]
        self._telegram_app = None

    def set_telegram_app(self, app):
        self._telegram_app = app

    async def start(self):
        if self.active:
            return False
        if not self.iq_client or not self.iq_client.esta_conectado():
            return False
        self.active = True
        self.task = asyncio.create_task(self._loop())
        logger.info("🤖 AutoSignalGenerator STARTED")
        return True

    async def stop(self):
        if not self.active:
            return False
        self.active = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
        logger.info("🛑 AutoSignalGenerator STOPPED")
        return True

    async def _loop(self):
        try:
            while self.active:
                try:
                    self._cleanup()
                    # REGRA: sinais manuais têm prioridade absoluta
                    if len(self.runtime.sinais_agendados) > 0:
                        logger.debug("⏸️ Manual signals exist - skipping auto generation")
                        await asyncio.sleep(10)
                        continue
                    if len(self.generated) >= self.max_per_hour:
                        logger.debug(f"⏸️ Hour limit reached ({self.max_per_hour})")
                        await asyncio.sleep(self.interval)
                        continue
                    if self.last_signal_time:
                        elapsed = (datetime.now(TZ) - self.last_signal_time).total_seconds()
                        if elapsed < self.cooldown_seconds:
                            remaining = int(self.cooldown_seconds - elapsed)
                            logger.debug(f"⏸️ Cooldown: {remaining}s remaining")
                            await asyncio.sleep(min(remaining, 30))
                            continue
                    signal = await self._generate()
                    if signal:
                        if self.config.get("show_signals_in_chat", False):
                            await self._send_signal_message(signal)
                        self.runtime.adicionar_sinal(signal)
                        self.generated.append({"timestamp": datetime.now(TZ), "asset": signal["par"]})
                        self.last_signal_time = datetime.now(TZ)
                        logger.info(f"✅ Auto signal generated: {signal['par']} {signal['direcao']} ({signal.get('confianca',0)}%)")
                    await asyncio.sleep(self.interval)
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"❌ Loop error: {e}")
                    import traceback
                    logger.error(traceback.format_exc())
                    await asyncio.sleep(self.interval)
        finally:
            logger.info("🏁 AutoSignalGenerator loop ended")

    async def _generate(self) -> Optional[Dict]:
        try:
            asset_data = await self._fetch_candles()
            if not asset_data:
                return None
            asset = asset_data["asset"]
            candles = asset_data["candles"]
            logger.info(f"📊 Fetched {len(candles)} candles for {asset}")
            if not self._validate_candles(candles):
                return None
            local = self._local_analysis(candles)
            ai_result = await self._analyze_with_ai(asset, candles, local)
            if not ai_result or not ai_result.get("valid"):
                return None
            if ai_result["confidence"] < self.min_confidence:
                logger.debug(f"⚠️ Low confidence: {ai_result['confidence']}%")
                return None
            is_otc = "-OTC" in asset.upper()
            timeframe = "M1"
            entry_time = (datetime.now(TZ) + timedelta(seconds=10)).strftime("%H:%M")
            signal = {
                "par": asset,
                "direcao": ai_result["direction"],
                "tempo_expiracao": 60,
                "horario": datetime.now(TZ) + timedelta(seconds=10),
                "imediato": False,
                "formato": "AUTO_AI",
                "origem": "AUTOMATIC",
                "confianca": ai_result["confidence"],
                "motivo": ai_result.get("reason", "AI analysis"),
                "_timeframe": timeframe,
                "_entry_time": entry_time,
                "_is_otc": is_otc,
                "_winrate": ai_result.get("winrate", 60),
                "_volatility": local.get("volatility", "MEDIUM"),
                "_trend_bias": local.get("trend_bias", "NEUTRAL"),
                "_ai_confirmed": True,
                "_confluences": local.get("confluences", 1),
            }
            return signal
        except Exception as e:
            logger.error(f"❌ Generation error: {e}")
            return None

    def _validate_candles(self, candles) -> bool:
        if not candles or len(candles) < 20:
            return False
        for c in candles[-5:]:
            try:
                close = c["close"] if isinstance(c, dict) else c.close
                if close <= 0:
                    return False
            except (KeyError, AttributeError):
                return False
        return True

    def _local_analysis(self, candles) -> Dict:
        try:
            def gc(c): return c["close"] if isinstance(c, dict) else c.close
            def go(c): return c["open"] if isinstance(c, dict) else c.open
            def gh(c): return c["max"] if isinstance(c, dict) else c.max
            def gl(c): return c["min"] if isinstance(c, dict) else c.min
            last20 = candles[-20:]
            last10 = candles[-10:]
            up = sum(1 for c in last10 if gc(c) > go(c))
            down = sum(1 for c in last10 if gc(c) < go(c))
            if up >= 7:
                trend_bias = "BULLISH"
            elif down >= 7:
                trend_bias = "BEARISH"
            else:
                trend_bias = "NEUTRAL"
            ranges = [gh(c) - gl(c) for c in last20]
            avg_range = sum(ranges) / len(ranges) if ranges else 0
            cur_range = gh(candles[-1]) - gl(candles[-1])
            vol_ratio = cur_range / avg_range if avg_range > 0 else 1
            if vol_ratio > 1.5:
                volatility = "HIGH"
            elif vol_ratio < 0.5:
                volatility = "LOW"
            else:
                volatility = "MEDIUM"
            confluences = 0
            if trend_bias != "NEUTRAL":
                confluences += 1
            if volatility in ("MEDIUM", "HIGH"):
                confluences += 1
            return {"trend_bias": trend_bias, "volatility": volatility,
                    "confluences": confluences, "up_candles": up, "down_candles": down}
        except Exception as e:
            logger.debug(f"Local analysis error: {e}")
            return {"trend_bias": "NEUTRAL", "volatility": "MEDIUM", "confluences": 1}

    async def _fetch_candles(self) -> Optional[Dict]:
        """Busca candles usando apenas API pública do myiq"""
        for asset in self.assets:
            try:
                # Usar a camada de integração para validar e obter active_id
                if hasattr(self.iq_client, '_integration') and self.iq_client._integration:
                    validation = await self.iq_client._integration.validate_asset_live(asset)
                    
                    if not validation.get("valid"):
                        continue
                    
                    active_id = validation["active_id"]
                    
                    try:
                        candles = await asyncio.wait_for(
                            self.iq_client.iq.get_candles(int(active_id), 60, 100),
                            timeout=15.0
                        )
                        if candles and len(candles) >= 20:
                            logger.info(f"📊 Candles obtidos: {asset} ({len(candles)})")
                            return {"asset": asset, "candles": candles}
                    except asyncio.TimeoutError:
                        logger.debug(f"Timeout candles {asset}")
                    except Exception as e:
                        logger.debug(f"Erro candles {asset}: {e}")
                        
            except Exception as e:
                logger.debug(f"❌ Error fetching {asset}: {e}")
        
        return None

    async def _analyze_with_ai(self, asset: str, candles, local: Dict) -> Optional[Dict]:
        if not self.gemini_client:
            return self._fallback_analysis(candles, local)
        try:
            prompt = self._build_prompt(asset, candles, local)
            response = await asyncio.wait_for(
                asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: self.gemini_client.chat.completions.create(
                        model="gemini-1.5-pro",
                        messages=[{"role": "user", "content": prompt}],
                        temperature=0.2,
                        max_tokens=300
                    )
                ),
                timeout=12.0
            )
            content = response.choices[0].message.content.strip()
            if content.startswith("```"):
                content = content.replace("```json", "").replace("```", "").strip()
            data = json.loads(content)
            if not data.get("valid"):
                return None
            if data["direction"] not in ["CALL", "PUT"]:
                return None
            return {
                "valid": True,
                "direction": data["direction"],
                "confidence": int(data.get("confidence", 0)),
                "reason": data.get("reason", ""),
                "winrate": int(data.get("winrate", 60))
            }
        except asyncio.TimeoutError:
            logger.debug("⏱️ Gemini timeout — usando análise local")
            return self._fallback_analysis(candles, local)
        except Exception as e:
            err = str(e)
            if "404" in err or "403" in err:
                logger.debug("⚠️ Gemini indisponível para esta key — usando análise local")
            else:
                logger.warning(f"⚠️ Gemini erro inesperado: {e}")
            return self._fallback_analysis(candles, local)

    def _build_prompt(self, asset: str, candles, local: Dict) -> str:
        def gc(c): return c["close"] if isinstance(c, dict) else c.close
        def go(c): return c["open"] if isinstance(c, dict) else c.open
        def gh(c): return c["max"] if isinstance(c, dict) else c.max
        def gl(c): return c["min"] if isinstance(c, dict) else c.min
        last_10 = candles[-10:]
        lines = []
        for i, c in enumerate(last_10, 1):
            trend = "🟢" if gc(c) > go(c) else "🔴"
            lines.append(f"{i}. {trend} O:{go(c):.5f} C:{gc(c):.5f} H:{gh(c):.5f} L:{gl(c):.5f}")
        candle_text = "\n".join(lines)
        return f"""Analyze this forex asset for binary options trading.

ASSET: {asset}
TIMEFRAME: 1 minute
LOCAL ANALYSIS:
  Trend Bias: {local.get('trend_bias', 'NEUTRAL')}
  Volatility: {local.get('volatility', 'MEDIUM')}
  Up Candles (last 10): {local.get('up_candles', 0)}/10
  Down Candles (last 10): {local.get('down_candles', 0)}/10

LAST 10 CANDLES:
{candle_text}

TASK:
Determine if there is a high-probability trading opportunity (confidence >= 70%).

RULES:
- Return ONLY valid JSON
- If no clear opportunity return {{"valid": false}}
- Only suggest CALL or PUT if confidence >= 70%
- Consider: trend, momentum, candlestick patterns, support/resistance

RESPONSE FORMAT:
{{
    "valid": true/false,
    "direction": "CALL" or "PUT" (only if valid=true),
    "confidence": 0-100,
    "winrate": 55-85,
    "reason": "brief technical reason"
}}

Return JSON only:"""

    def _fallback_analysis(self, candles, local: Dict = None) -> Optional[Dict]:
        try:
            local = local or self._local_analysis(candles)
            up = local.get("up_candles", 0)
            down = local.get("down_candles", 0)
            if up >= 7:
                return {"valid": True, "direction": "CALL",
                        "confidence": min(82, int((up / 10) * 100)),
                        "winrate": 62, "reason": f"Uptrend {up}/10 candles (fallback)"}
            elif down >= 7:
                return {"valid": True, "direction": "PUT",
                        "confidence": min(82, int((down / 10) * 100)),
                        "winrate": 62, "reason": f"Downtrend {down}/10 candles (fallback)"}
            return None
        except Exception:
            return None

    async def _send_signal_message(self, signal: Dict):
        """Envia mensagem de sinal formatada para o chat Telegram"""
        try:
            # Corrigido: self.runtime.auto_trader nao existe.
            # Usa GRUPO_ID diretamente do config/env.
            from state.config import GRUPO_ID
            chat_id = GRUPO_ID
            if not chat_id:
                return
            app = self._telegram_app
            if not app:
                from state import runtime as rt
                app = getattr(rt, "_telegram_app", None)
            if not app:
                return
            asset = signal["par"]
            direction = signal["direcao"]
            timeframe = signal.get("_timeframe", "M1")
            entry_time = signal.get("_entry_time", "")
            is_otc = signal.get("_is_otc", "-OTC" in asset)
            confidence = signal.get("confianca", 0)
            winrate = signal.get("_winrate", 60)
            confluences = signal.get("_confluences", 1)
            ai_confirmed = signal.get("_ai_confirmed", False)
            volatility = signal.get("_volatility", "MEDIUM")
            trend_bias = signal.get("_trend_bias", "NEUTRAL")
            value = self.config.get("valor_entrada", 10.0)
            market = "OTC" if is_otc else "OPEN"
            dir_emoji = "📈" if direction == "CALL" else "📉"
            ai_text = "YES ✅" if ai_confirmed else "NO ❌"
            parser_line = f"{timeframe} {asset} {direction} {entry_time}" if entry_time else f"{timeframe} {asset} {direction}"
            msg = (
                f"━━━━━━━━━━━━━━━━━━\n"
                f"📡 <b>NOVO SINAL</b>\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"📊 {asset} · {timeframe} · {market}\n"
                f"{dir_emoji} <b>{direction}</b>"
                + (f" · 🕒 {entry_time}" if entry_time else "") + "\n"
                f"💰 ${value:.2f}  |  🏆 {winrate}%  |  🔥 {confluences}x\n"
                f"🧠 IA: {ai_text}  |  📊 {volatility}  |  📉 {trend_bias}\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"<code>{parser_line}</code>"
            )
            await app.bot.send_message(chat_id=chat_id, text=msg, parse_mode="HTML")
            logger.info(f"📤 Signal message sent: {asset} {direction}")
        except Exception as e:
            logger.error(f"❌ Error sending signal message: {e}")

    def _cleanup(self):
        now = datetime.now(TZ)
        self.generated = [
            s for s in self.generated
            if (now - s["timestamp"]).total_seconds() < 3600
        ]
